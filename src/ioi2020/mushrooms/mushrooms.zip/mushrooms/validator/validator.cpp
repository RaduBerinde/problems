
#include "testlib.h"
using namespace std;

const int min_n = 2;
const int max_n = 20000;

inline int read_n() {
	return inf.readInt(min_n, max_n, "n");
}

int main() {
	registerValidation();
	string strategy = inf.readLine();
	if (strategy == "plain") {
		int n = read_n();
		inf.readEoln();
		auto species = inf.readInts(n, 0, 1, "species");
		inf.readEoln();
		inf.ensuref(species[0] == 0, "First element must be of type 0");
	} else if (strategy == "adversary_simple_random") {
		read_n();
		inf.readSpace();
		inf.readInt(); // seed
		inf.readEoln();
	} else if (strategy == "adversary_balanced_random") {
        read_n();
        inf.readSpace();
        inf.readDouble(0, 1, "p");
        inf.readSpace();
        inf.readInt(); // seed
        inf.readEoln();
    } else if (strategy == "adversary_small_equal") {
		int n = read_n();
		inf.readSpace();
		inf.readInt(0, n, "qthreshold");
		inf.readSpace();
		inf.readInt(0, 1, "total_equalizing");
		inf.readSpace();
		inf.readInt(); // seed
		inf.readEoln();
    } else 
		inf.quitf(_fail, "Unknown grading strategy '%s'", strategy.c_str());
	inf.readEof();
	return 0;
}
