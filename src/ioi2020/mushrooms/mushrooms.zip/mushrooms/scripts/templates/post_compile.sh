set -euo pipefail

# Post-compilation hook script

# Currently empty
