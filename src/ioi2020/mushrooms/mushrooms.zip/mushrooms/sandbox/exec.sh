#!/bin/bash

problem_name=mushrooms
sandbox=$(dirname "$0")

"${sandbox}/${problem_name}.exe" "$@"
